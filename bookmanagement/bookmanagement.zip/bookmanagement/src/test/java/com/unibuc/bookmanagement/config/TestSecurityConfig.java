package com.unibuc.bookmanagement.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@Profile("test") // Se aplică doar când rulezi cu profilul "test"
public class TestSecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // 🔴 DEZACTIVEAZĂ CSRF
            .authorizeHttpRequests(auth -> auth.anyRequest().permitAll()); // 🔓 Permite tot
        return http.build();
    }
}
